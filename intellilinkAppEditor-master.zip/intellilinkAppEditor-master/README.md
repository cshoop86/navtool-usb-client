# intellilinkAppEditor

A small editor for Opel/Vauxhall/GM Intellilink/MyLink < 4.0 ClientAppInfo.bin files.
Reads and writes ClientAppInfo.bin files.

The software is provided 'as is', without warranty of any kind.
